// Simple regular expression matcher.
// See Regex.cpp for attribution, description and discussion

// Returns true if text contains the regular expression regexp
bool regexMatch(const char* regexp, const char* text);
