// Copyright (c) 2022 -	Neil
#include "../../Grbl.h"
#include "../SJMotorCtrl.h"
#include "../PointQueue.h"
#include "AccelStepper.h"
#include "MultiStepper.h"
#include "FS.h"
#include "SPIFFS.h"
#include "../../SettingsDefinitions.h"

// extern portMUX_TYPE myMutex;
extern parser_state_t gc_state;
extern parser_block_t gc_block;

extern FloatSetting* sj_cfg_l_chn_x_offset;
extern FloatSetting* sj_cfg_l_chn_Y_offset;
extern FloatSetting* sj_cfg_r_chn_X_offset;
extern FloatSetting* sj_cfg_r_chn_y_offset;
extern FloatSetting* sj_cfg_sps_x_offset;
extern FloatSetting* sj_cfg_sps_y_offset;

int   lastDirX       = 0;
int   lastDirY       = 0;
long  laserSteps     = 0;
float posY           = 0;
bool  lasering       = false;
float distance       = 0;
float loadMateLength = 50;  //加载物料的长度

float spacer         = 0.075;  //0.064;
float backDistance   = 0.3;
float bankDistance   = 2;
float accleDistance  = 12;
int   g_MaxSpeed     = 3000;  //90000;
int   g_MaxAccel     = 5000;  //120000;
int   g_SafeMode     = 0;
bool  g_PauseAndStop = 0;

long toStepX(float mm) {
    float steps_per_mm = axis_settings[X_AXIS]->steps_per_mm->get();
    return steps_per_mm * mm;
}

float toMMX(long vSteps) {
    float steps_per_mm = axis_settings[X_AXIS]->steps_per_mm->get();
    return vSteps / steps_per_mm;
}

long toStepY(float mm) {
    float steps_per_mm = axis_settings[Y_AXIS]->steps_per_mm->get();
    return steps_per_mm * mm;
}

float toMMY(long vSteps) {
    float steps_per_mm = axis_settings[Y_AXIS]->steps_per_mm->get();
    return vSteps / steps_per_mm;
}

long toStepZ(float mm) {
    float steps_per_mm = axis_settings[Z_AXIS]->steps_per_mm->get();
    return steps_per_mm * mm;
}

float toMMZ(long vSteps) {
    float steps_per_mm = axis_settings[Z_AXIS]->steps_per_mm->get();
    return vSteps / steps_per_mm;
}

int dirs = 0;

void forwardX(void) {
    dirs &= ~(bit(X_AXIS));

    motors_direction(dirs);
    motors_step(bit(X_AXIS));
}

void backwardX(void) {
    dirs |= bit(X_AXIS);

    motors_direction(dirs);
    motors_step(bit(X_AXIS));
}

void forwardY(void) {
    dirs &= ~(bit(Y_AXIS));

    motors_direction(dirs);
    motors_step(bit(Y_AXIS));
}

void backwardY(void) {
    dirs |= bit(Y_AXIS);

    motors_direction(dirs);
    motors_step(bit(Y_AXIS));
}

void forwardZ(void) {
    dirs |= bit(Z_AXIS);

    motors_direction(dirs);
    motors_step(bit(Z_AXIS));
}

void backwardZ(void) {
    dirs &= ~(bit(Z_AXIS));

    motors_direction(dirs);
    motors_step(bit(Z_AXIS));
}
//////////////////////////////////////////////////////////////////
AccelStepper motorX(forwardX, backwardX);
AccelStepper motorY(forwardY, backwardY);
AccelStepper motorZ(forwardZ, backwardZ);

//////////////////////////////////////////////////////////////////

void SJMotorCtrl::init() {
    motorX.setAcceleration(5000);
    motorX.setSpeed(0);
    motorX.setCurrentPosition(0);
    motorX.setMaxSpeed(3000);

    motorZ.setAcceleration(toStepZ(500));
    motorZ.setSpeed(0);
    motorZ.setCurrentPosition(0);
    motorZ.setMaxSpeed(toStepZ(500 / 60));
}

void SJMotorCtrl::loop() {}

bool SJMotorCtrl::yAxisHoming(uint8_t client) {
    //初始Y轴
    motorY.setAcceleration(toStepY(3000));
    motorY.setSpeed(0);
    motorY.setMaxSpeed(toStepY(3000 / 60)); 
    motorY.runToNewPosition(-(motorY.currentPosition()));
 
}
bool SJMotorCtrl::zAxisHoming(uint8_t client) {
      sys.state = State::Homing;
#if defined(PEN1_END_STOP) && defined(PEN2_END_STOP)
    //假设电机负方向是往左转
    //下笔最深5mm

    //如果两个限位都没有碰到，属于异常情况
    if (digitalRead(PEN1_END_STOP) != PEN_TOUCH && digitalRead(PEN2_END_STOP) != PEN_TOUCH) {
        grbl_sendf(CLIENT_ALL, "err:pen check 0\r\n");
        sys.state = State::Idle;  //Alarm
        return false;
    }

    motors_unstep();
    motors_set_disable(false);

    //如果左边限位没有碰到，电机往右转，抬起左边压轮
    motorZ.moveTo(toStepZ(10));
    while (motorZ.distanceToGo()) {
        if (digitalRead(PEN1_END_STOP) == PEN_TOUCH)
            break;

        motorZ.run();
        yield();
    }

    //如果转动完，左边限位还没碰到，属于异常情况
    if (motorZ.distanceToGo() == 0) {
        motors_unstep();
        motors_set_disable(true);
        grbl_sendf(CLIENT_ALL, "err:pen check 1\r\n");
        sys.state = State::Idle;  //Alarm
        return false;
    }

    //如果右边限位没有碰到，电机往左转，抬起右边压轮
    motorZ.moveTo(toStepZ(-10));
    while (motorZ.distanceToGo()) {
        if (digitalRead(PEN2_END_STOP) == PEN_TOUCH)
            break;

        motorZ.run();
        yield();
    }

    //如果转动完，右边限位还没碰到，属于异常情况
    if (motorZ.distanceToGo() == 0) {
        motors_unstep();
        motors_set_disable(true);
        grbl_sendf(CLIENT_ALL, "err:pen check 2\r\n");
        sys.state = State::Idle;  //Alarm
        return false;
    }

    //这时，应该左右限位都碰到
    if (digitalRead(PEN1_END_STOP) != PEN_TOUCH || digitalRead(PEN2_END_STOP) != PEN_TOUCH) {
        motors_unstep();
        motors_set_disable(true);
        grbl_sendf(CLIENT_ALL, "err:pen check 3\r\n");
        sys.state = State::Idle;  //Alarm
        return false;
    }

    //粗略设置当前坐标为0
    motorZ.setCurrentPosition(0);

    //压左边轮子，使左边笔离开限位开关
    motorZ.moveTo(toStepZ(-10));
    while (motorZ.distanceToGo()) {
        if (digitalRead(PEN1_END_STOP) != PEN_TOUCH)
            break;

        motorZ.run();
        yield();
    }

    //测得需要下压的距离
    float tPosLeft = toMMZ(motorZ.currentPosition());

    //右转压右边轮子，使右边笔离开限位开关
    motorZ.moveTo(toStepZ(10));
    while (motorZ.distanceToGo()) {
        if (digitalRead(PEN2_END_STOP) != PEN_TOUCH)
            break;

        motorZ.run();
        yield();
    }

    //测得需要下压的距离
    float tPosRight = toMMZ(motorZ.currentPosition());

    //取得中间点
    float tPosMid = (tPosLeft + tPosRight) / 2;
    motorZ.moveTo(toStepZ(tPosMid));
    while (motorZ.distanceToGo()) {
        motorZ.run();
        yield();
    }
 
    motors_unstep();
    motors_set_disable(true);
    motorZ.setCurrentPosition(0); 

    //设置Z坐标为0
    gc_block.values.xyz[Z_AXIS] = 0;
    memcpy(gc_state.coord_offset, gc_block.values.xyz, sizeof(gc_block.values.xyz));
    system_flag_wco_change();

    //额外计算左右下压的空行程（数值为正)
    float tBankDistance = (tPosRight - tPosLeft) / 2;
    grbl_sendf(CLIENT_ALL, "pen home ok bank %0.2f\r\n", tBankDistance);
#endif
    sys.state = State::Idle;  //Alarm
    return true;
}

bool SJMotorCtrl::xyAxisHoming(uint8_t client, bool vMiddle) {
    SJMotorCtrl::enableMotor();
    motorX.setAcceleration(toStepX(2000));
    motorX.setSpeed(0);
    motorX.setCurrentPosition(0);
    motorX.setMaxSpeed(toStepX(2000 / 60));

    sys.state = State::Homing;

    //向右移，直到小车离开限位
    motorX.moveTo(toStepX(30));
    while (motorX.distanceToGo()) {
        if (digitalRead(X_LIMIT_PIN) != LIMIT_TOUCH)
            break;

        motorX.run();
        yield();
    }

    //如果转动完，限位还没离开，属于异常情况
    if (motorX.distanceToGo() == 0) {
        motors_unstep();
        motors_set_disable(true);
        grbl_sendf(CLIENT_ALL, "error:1000\r\n");

        sys.state = State::Idle;  //Alarm
        return false;
    }

    //停下
    motorX.stop();
    motorX.runToPosition();

    //往限位靠近
    motorX.setCurrentPosition(0);
    motorX.moveTo(toStepX(-350));

    //直到碰到限位
    while (motorX.distanceToGo()) {
        if (digitalRead(X_LIMIT_PIN) == LIMIT_TOUCH)
            break;

        motorX.run();
        yield();
    }

    //如果转动完，限位还没碰到，属于异常情况
    if (motorX.distanceToGo() == 0) {
        motors_unstep();
        motors_set_disable(true);
        grbl_sendf(CLIENT_ALL, "error:1001\r\n");
        sys.state = State::Idle;  //Alarm
        return false;
    }

    //远离一点限位
    motorX.setCurrentPosition(0);
    motorX.moveTo(toStepX(3));

    while (motorX.distanceToGo()) {
        motorX.run();
        yield();
    }

    //motors_unstep();
    //motors_set_disable(true);
    motorX.setCurrentPosition(0);
    motorY.setCurrentPosition(0);

    if (vMiddle) {
        motorX.moveTo(toStepX(150));
        while (motorX.distanceToGo()) {
            motorX.run();
            yield();
        }

        //设置XY坐标为0
        gc_block.values.xyz[X_AXIS] = -150;
        gc_block.values.xyz[Y_AXIS] = 0;
    } else {
        gc_block.values.xyz[X_AXIS] = 0;
        gc_block.values.xyz[Y_AXIS] = 0;
    }

    memcpy(gc_state.coord_offset, gc_block.values.xyz, sizeof(gc_block.values.xyz));

    //机械坐标清零
    //gc_state.coord_system[X_AXIS] = 0;
    //gc_state.coord_system[Y_AXIS] = 0;

    system_flag_wco_change();

    grbl_sendf(CLIENT_ALL, "[MSG]HOME OK\r\n");

    sys.state = State::Idle;

    SJMotorCtrl::disableMotor();

    return true;
}

void SJMotorCtrl::enableMotor(void) {
    motors_unstep();
    motors_set_disable(false);
}

void SJMotorCtrl::disableMotor(void) {
    motors_unstep();
    motors_set_disable(true);
}

void SJMotorCtrl::runTest(uint8_t client) {
    // 任务运行状态操作无效
    if (SJCutterIns.taskRunStatus) {
        return;
    }

    SJCutterIns.testMode = true;
    SJMotorCtrl::zAxisHoming(client);

    SJMotorCtrl::xyAxisHoming(client, false);

    SJMotorCtrl::enableMotor();

    motorX.setAcceleration(toStepX(2000));
    motorX.setSpeed(0);
    motorX.setCurrentPosition(0);
    motorX.setMaxSpeed(toStepX(4000 / 60));

    motorY.setAcceleration(toStepY(2000));
    motorY.setSpeed(0);
    motorY.setCurrentPosition(0);
    motorY.setMaxSpeed(toStepY(4000 / 60));

    motorZ.setAcceleration(toStepZ(2000));
    motorZ.setSpeed(0);
    motorZ.setCurrentPosition(0);
    motorZ.setMaxSpeed(toStepZ(4000 / 60));

    while (SJCutterIns.testMode) {
        // 中止测试
        int tValue = analogRead(PIN_MENU_KEY);
        if (tValue < 3000) {
            break;
        }

        motorX.run();
        motorY.run();
        motorZ.run();

        if (motorX.distanceToGo() == 0)
            if (motorX.currentPosition() == 0)
                motorX.moveTo(toStepX(300));
            else
                motorX.moveTo(toStepX(0));

        if (motorY.distanceToGo() == 0)
            if (motorY.currentPosition() == 0)
                motorY.moveTo(toStepY(300));
            else
                motorY.moveTo(toStepY(0));

        if (motorZ.distanceToGo() == 0)
            if (motorZ.currentPosition() < 0)
                motorZ.moveTo(toStepZ(2.5));
            else
                motorZ.moveTo(toStepZ(-2.5));

        yield();
    }

    SJMotorCtrl::disableMotor();

    SJMotorCtrl::xyAxisHoming(client, false);

    SJMotorCtrl::zAxisHoming(client);

    SJCutterIns.testMode = false;
}

bool SJMotorCtrl::loadMate(uint8_t client) {
    return SJMotorCtrl::absMoveAxis(client, Y_AXIS, 0);
};
bool SJMotorCtrl::unLoadMate(uint8_t client) {
    float mate_dist = sj_cfg_y_mate_dist->get();
    return SJMotorCtrl::absMoveAxis(client, Y_AXIS, mate_dist);
}
bool SJMotorCtrl::resetAxis(uint8_t client) {
    char cmdLine[64];
    // // 重置Y轴0位；
    // memset(cmdLine,0,64);
    // sprintf(cmdLine, "G10 P0 L20 Y0");
    // execute_line(cmdLine, client, WebUI::AuthenticationLevel::LEVEL_GUEST);

    // X轴归位
    memset(cmdLine,0,64);
    sprintf(cmdLine, "$hx");
    execute_line(cmdLine, client, WebUI::AuthenticationLevel::LEVEL_GUEST);
    // X轴移动到中间
    float x_pulloff_dist = sj_cfg_x_pulloff_dist->get();    
    memset(cmdLine,0,64);
    sprintf(cmdLine, "G0 X%3.2f Y0 F5000",x_pulloff_dist);
    // sprintf(cmdLine, "G0 X153 Y0 F5000");
    // grbl_sendf(client,"%s\n\0", cmdLine);
    execute_line(cmdLine, client, WebUI::AuthenticationLevel::LEVEL_GUEST);

}
bool SJMotorCtrl::absMoveAxis(uint8_t client, uint axis, float moveDist) {
    char jogLine[LINE_BUFFER_SIZE];
    sprintf(jogLine, "$J=G90G21%s%3.2fF5000", axis == 0 ? "X" : "Y", moveDist);
    gc_execute_line(jogLine, client);
    // grbl_sendf(client, "mateLoadStatus:%s\r\n",jogLine);
    return true;
};
bool SJMotorCtrl::relMoveAxis(uint8_t client, uint axis, float moveDist) {
    char jogLine[LINE_BUFFER_SIZE];
    sprintf(jogLine, "$J=G91G21%s%3.2fF5000", axis == 0 ? "X" : "Y", moveDist);
    // grbl_send(client, jogLine);
    gc_execute_line(jogLine, client);
    return true;
};

_PointInfo SJMotorCtrl::cacleExtendLength(_PointInfo pointA, _PointInfo pointB, float length) {
    float lengthX    = pointB.x - pointA.x;
    float lengthY    = pointB.y - pointA.y;
    float btwlength  = sqrt(pow(lengthX, 2) + pow(lengthY, 2));
    float nextPointX = pointB.x + (lengthX / btwlength * length);
    float nextPointY = pointB.y + (lengthY / btwlength * length);
    return { x: nextPointX, y: nextPointY };
}

_PointInfo SJMotorCtrl::cacleIntersect(_PointInfo p1, _PointInfo p2, _PointInfo p3, _PointInfo p4) {
    // Store the values for fast access and easy
    // equations-to-code conversion
    float x1 = p1.x, x2 = p2.x, x3 = p3.x, x4 = p4.x;
    float y1 = p1.y, y2 = p2.y, y3 = p3.y, y4 = p4.y;

    float d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
    // If d is zero, there is no intersection
    if (d == 0)
        return { x: 0, y: 0, status: false };

    // Get the x and y
    float pre = (x1 * y2 - y1 * x2), post = (x3 * y4 - y3 * x4);
    float x = (pre * (x3 - x4) - (x1 - x2) * post) / d;
    float y = (pre * (y3 - y4) - (y1 - y2) * post) / d;

    // Check if the x and y coordinates are within both lines
    if (x < min(x1, x2) || x > max(x1, x2) || x < min(x3, x4) || x > max(x3, x4))
        return { x: 0, y: 0, status: false };
    if (y < min(y1, y2) || y > max(y1, y2) || y < min(y3, y4) || y > max(y3, y4))
        return { x: 0, y: 0, status: false };

    return { x: x, y: y , status: true };
}

float SJMotorCtrl::cacleAngle(_PointInfo p1, _PointInfo2 p2, _PointInfo2 p3) {
    float x1    = (p1.x - p3.x);
    float y1    = (p1.y - p3.y);
    float x2    = (p2.x - p3.x);
    float y2    = (p2.y - p3.y);
    float dot   = x1 * x2 + y1 * y2;
    float det   = x1 * y2 - y1 * x2;
    float angle = atan2(det, dot) / PI * 180;
    float ang   = fmod(angle, 360.0);  
    if (ang < 0.0)
        ang = 360.0 + ang;
    return ang ;
}

bool SJMotorCtrl::SeekMark(int vClient, int taskIndex, float width, float height) {
    //允许出现的偏移范围+-10
    float max_offset = 25;  //mm
    //标记线宽
    float mark_line_width = 5;  //mm
    // 标记与页边间距
    float marks_margin[4] = { 5, 5, 30, 5 };  // 上，左，下，右
    //定义找寻范围
    // float leftTopRange[2][2] = { {0, marks_margin[3] + max_offset+10 }, {0, marks_margin[0] + max_offset+15 } };
    // float rightBottomRange[2][2] = { { width - (marks_margin[1]-10),width - (marks_margin[1] + max_offset) },
    //  { height - (marks_margin[2]-10),height - (marks_margin[2] + max_offset) } };

    //左上角查找范围 {{minX,maxX,safeX},{minY,maxY,safeY}}
   _ValRange leftTopRange[2] = { _ValRange { 0, 40, 20 }, _ValRange { 0, 40, 18 } };
    //右下角查找范围 {{maxX,minX,safeX},{maxY,minY,safeY}}
    _ValRange rightBottomRange[2] = { _ValRange { width , width - 40, width - 15 }, _ValRange { height - 27, height - 50, height - 50 } };

    //电机准备
    motors_unstep();
    motors_set_disable(false);
    int speed = 10000;

    //初始X轴
    motorX.setAcceleration(toStepX(speed));
    motorX.setSpeed(0);
    motorX.setMaxSpeed(toStepX(speed / 60));

    //初始Y轴
    motorY.setAcceleration(toStepY(speed));
    motorY.setSpeed(0);
    motorY.setMaxSpeed(toStepY(speed / 60));

    // 回到原位
    motorX.runToNewPosition(toStepX(0));
    motorY.runToNewPosition(toStepY(0));

    float currXPos = toMMX(motorX.currentPosition());
    float currYPos = toMMY(motorY.currentPosition());

    bool seekstatus = false;
    //开启寻边传感器
    pinMode(PIN_SEEK_BOX, INPUT);

    //找左上点

    _PointInfo2 leftTopPoint = SJMotorCtrl::SeekMarkPoint(vClient, leftTopRange);

    // 回到原位
    motorX.runToNewPosition(toStepX(currXPos));
    motorY.runToNewPosition(toStepY(currYPos));

    // 判断是否找到左上点
    if (leftTopPoint.status) {
        // 找右下点
       _PointInfo2 rightBottomPoint = SJMotorCtrl::SeekMarkPoint(vClient, rightBottomRange);
        // grbl_sendf(vClient, "rightBottomPoint %0.2f,%0.2f\r\n", rightBottomPoint.x, rightBottomPoint.y);
        // 判断是否找到右下点
        if (rightBottomPoint.status) {
            // 计算页边间距
            float xaxis_margin = (marks_margin[1] + marks_margin[3]);
            float yaxis_margin = (marks_margin[0] + marks_margin[2]);

           // float realwidth = width - xaxis_margin;
             float realwidth = (rightBottomPoint.x2 - leftTopPoint.x2 );
           // float realheight = height - yaxis_margin;
            float realheight = (rightBottomPoint.y2 - leftTopPoint.y2 );

           float Zoom_ratioX = (rightBottomPoint.x2 - leftTopPoint.x2 ) / 187.5;
           float Zoom_ratioY = (rightBottomPoint.y2 - leftTopPoint.y2 ) / 246.7;

            // 计算无偏移情况下右下应该出现的位置
            _PointInfo vrbPoint = { x: leftTopPoint.x + realwidth, y: leftTopPoint.y + realheight };  // 虚拟左下点
            

            grbl_sendf(vClient,
                       "SEEK: %d,%0.5f,%0.5f,%0.5f,%0.5f,%0.5f\r\n",
                       taskIndex,
                       (leftTopPoint.x) - 11.5,
                       (leftTopPoint.y) - 13.2,
                      (SJMotorCtrl::cacleAngle(vrbPoint, rightBottomPoint, leftTopPoint)),
                       Zoom_ratioX,
                       Zoom_ratioY
                       );
            seekstatus = true;
        }
    }

    // 回到原位
    motorX.runToNewPosition(toStepX(currXPos));
    motorY.runToNewPosition(toStepY(currYPos));

    //归位
    // motorX.runToNewPosition(0);
    // motorY.runToNewPosition(0);

    //释放电机
    motors_unstep();
    motors_set_disable(true);

    return seekstatus;
}

_PointInfo2 SJMotorCtrl::SeekMarkPoint(int vClient, _ValRange target_range[2]) {
    // 找寻推进模式
    int seek_mode[2] = { 0, 0 };  //{X方向，Y方向}，0 正向，1 反向
    // 找寻推进步长
    float seek_step = 0.01;
    // _PointInfo sensorOffset = { x: 14, y: 34.50 };
    // _PointInfo sensorOffset = { x: 13, y: 35 };
    // _PointInfo sensorOffset = { x: 13.97, y: 34.26 };

    // 刀通道偏移
    _PointInfo penOffset = { x: sj_cfg_r_chn_x_offset->get(), y: sj_cfg_r_chn_y_offset->get() };
    // 光传感器偏移
    _PointInfo spsOffset = { x: sj_cfg_sps_x_offset->get(), y: sj_cfg_sps_y_offset->get() };
    // 组合偏移
    _PointInfo sensorOffset = { x: penOffset.x + spsOffset.x, y: penOffset.y + spsOffset.y };
    // 设置找寻范围
    float seekXArea[3] = { target_range[0].min, target_range[0].max };  //[最小X，最大X]
    float seekYArea[3] = { target_range[1].min, target_range[1].max };  //[最小Y，最大Y]
    // 判断并设置找寻范围的方向
    seek_mode[0] = (seekXArea[0] < seekXArea[1] ? 0 : 1);
    seek_mode[1] = (seekYArea[0] < seekYArea[1] ? 0 : 1);

    // 保留连续的标记点,非连续标记点则清空
    PointQueue findXPonits;
    PointQueue findYPonits;
    
    float currXPos = toMMX(motorX.currentPosition());
    float currYPos = toMMY(motorY.currentPosition());
    float minXPos  = currXPos + seekXArea[0];
    float maxXPos  = currXPos + seekXArea[1];
    float minYPos  = currYPos + seekYArea[0];
    float maxYPos  = currYPos + seekYArea[1];

    // 固定X值，寻找X时Y不变
    float safePointX = currXPos + target_range[0].safe;
    // 固定Y值，寻找X时Y不变
    float safePointY = currYPos + target_range[1].safe;

    // 同一轴向安全点偏移距离
    float safePointOffset = 5;
    // X和Y方向分别探测两个点，两点形成的线进行延长，并计算延长后的交点
    _PointInfo testXPointA = SJMotorCtrl::TestSeekPointByArea(vClient, sensorOffset, 1, safePointY, minXPos, maxXPos, seek_step);
    if (testXPointA.status) {
        // grbl_sendf(vClient, "testXPointA %0.2f,%0.2f\r\n", testXPointA.x,testXPointA.y);
        // Y安全偏移量
        float yAxis_SafeOffset = (seek_mode[0] == 0 ? safePointOffset : -safePointOffset);
        _PointInfo testXPointB =SJMotorCtrl::TestSeekPointByArea(vClient, sensorOffset, 1, safePointY + yAxis_SafeOffset, minXPos, maxXPos, seek_step);
        if (testXPointB.status) {
            // grbl_sendf(vClient, "testXPointB %0.2f,%0.2f\r\n", testXPointB.x,testXPointB.y);
            _PointInfo testYPointA = SJMotorCtrl::TestSeekPointByArea(vClient, sensorOffset, 2, safePointX, minYPos, maxYPos, seek_step);
            if (testYPointA.status) {
                // grbl_sendf(vClient, "testYPointA %0.2f,%0.2f\r\n", testYPointA.x,testYPointA.y);
                // X安全偏移量
                 float xAxis_SafeOffset = (seek_mode[1] == 0 ? safePointOffset : -safePointOffset);
                _PointInfo testYPointB =SJMotorCtrl::TestSeekPointByArea(vClient, sensorOffset, 2, safePointX + xAxis_SafeOffset, minYPos, maxYPos, seek_step);
                if (testYPointB.status) {
                    //  grbl_sendf(vClient, "testYPointB %0.2f,%0.2f\r\n", testYPointB.x,testYPointB.y);
                    // 计算延长线
                    _PointInfo extXPoint = SJMotorCtrl::cacleExtendLength(testXPointB, testXPointA, 200);
                    _PointInfo extYPoint = SJMotorCtrl::cacleExtendLength(testYPointB, testYPointA, 200);
                    if(testYPointA.y <= 100)
                    {
                    float hightfactT = (testYPointA.y + testYPointB.y) / 2;
                    float widthfactT = (testXPointA.x + testXPointB.x) / 2;

                     _PointInfo intsPoint = SJMotorCtrl::cacleIntersect(testXPointA, extXPoint, testYPointB, extYPoint);

                    // grbl_sendf(vClient, " %0.2f,%0.2f,%0.2f,%0.2f\r\n", testYPointA.y,testYPointB.y,testXPointA.x,testXPointB.x);

                    if (intsPoint.status) {
                    // 得到减去偏移量后的值
                    return { x: intsPoint.x - sensorOffset.x - currXPos, y: intsPoint.y - sensorOffset.y - currYPos, x2:widthfactT ,y2:hightfactT ,status: true };
                    }
                    }
                    else
                    {
                    float hightfactD = (testYPointA.y + testYPointB.y) / 2;
                    float widthfactD = (testXPointA.x + testXPointB.x) / 2;

                    _PointInfo intsPoint = SJMotorCtrl::cacleIntersect(testXPointA, extXPoint, testYPointB, extYPoint);
                   // grbl_sendf(vClient, " %0.2f,%0.2f,%0.2f,%0.2f\r\n", testYPointA.y,testYPointB.y,testXPointA.x,testXPointB.x);

                    if (intsPoint.status) {
                    // 得到减去偏移量后的值
                    return { x: intsPoint.x - sensorOffset.x - currXPos, y: intsPoint.y - sensorOffset.y - currYPos, x2: widthfactD , y2: hightfactD , status: true };
                    }
                    }

                }
            }
        }
    }

    return { x: 0, y: 0, x2 : 0, y2 : 0, status: false };
}

_PointInfo SJMotorCtrl::TestSeekPointByArea(int vClient, _PointInfo sensorOffset, int axis, float safev, float val1, float val2, float step) {
    // 探测点队列
    PointQueue foundPonits;
    // foundPonits.clear();
    int mode = (val1 < val2 ? 0 : 1);
    // 迭代查找范围
    for (float i = val1; (mode < 1 ? (i < val2) : (i > val2)); i = (mode < 1 ? (i + step) : (i - step))) {
        // 中止查找
        int tValue = analogRead(PIN_MENU_KEY);
        if (tValue < 3000) {
            break;
        }
        // 测试目标轴
        float testx = 0;
        float testy = 0;
        // 判断当前测试轴，安全值将保持不变
        if (axis == 1) {
            testx = i;
            testy = safev;
        } else if (axis == 2) {
            testx = safev;
            testy = i;
        }
        // 从传感器获取目标位置是否为有标记
        int tag = SJMotorCtrl::TestSeekPointByXY(vClient, sensorOffset, testx, testy);
        if (tag > 0) {
            // motorX.stop();
            // 获取当前X位置
            long xstep = motorX.currentPosition();
            long ystep = motorY.currentPosition();
            // 保留减去偏移后的值
            foundPonits.push({ x: toMMX(xstep), y: toMMY(ystep) }, tag);
        }
        // 队列满时退出循环
        if (foundPonits.isFulled())
            break;
        // 按键中止循环
        // if (getKey() > 0) {
        //     foundPonits.clear();
        //     break;
        // }
        yield();
    }
    // 当存在连续的标记点时返回首个标记点
    if (foundPonits.isFulled()) {
        _PointInfo testPoint = foundPonits.front();
        return { x: testPoint.x, y: testPoint.y, status: true };
    }
    return { x: 0, y: 0, status: false };
}

int SJMotorCtrl::TestSeekPointByXY(int vClient, _PointInfo sensorOffset, float x, float y) {
    // x坐标最大值
    float max_xaxis = 345;
#if defined(PIN_SEEK_BOX)
    // 光传感器容差范围,分为四个区间0:传感器异常，1:白纸，2:垫板，3:标记物
    int   tolerance_range[4][2] = { { 0, 1 }, { 1, 2500 }, { 2500, 3800 }, { 3800, 5500 } };
    float runToX                = x + sensorOffset.x;
    float runToY                = y + sensorOffset.y;
    // 当超取识别范围直接判断为识别异常
    if (runToX <= max_xaxis) {
        // 移动电机到指定位置
        motorX.runToNewPosition(toStepX(runToX));
        motorY.runToNewPosition(toStepY(runToY));
        //获取寻边传感器值
        int psval  = analogRead(PIN_SEEK_BOX);
        int result = 0;
        if (psval >= tolerance_range[0][0] && psval < tolerance_range[0][1]) {
            result = 0;
        } else if (psval >= tolerance_range[1][0] && psval < tolerance_range[1][1]) {
            result = 1;
        } else if (psval >= tolerance_range[2][0] && psval < tolerance_range[2][1]) {
            result = 2;
        } else if (psval >= tolerance_range[3][0] && psval < tolerance_range[3][1]) {
            result = 3;
        }

        //   grbl_sendf(CLIENT_ALL, "Position %0.2f,%0.2f,%d\r\n", x,y,result);
        return result;
    } else {
        return 0;
    }

#else
    return 0;
#endif
}

bool SJMotorCtrl::SeekMark2(int vClient, int taskIndex, float width, float height) {
    //允许出现的偏移范围+-10
    float max_offset = 25;  //mm
    //标记线宽
    float mark_line_width = 5;  //mm
    // 标记与页边间距
    float marks_margin[4] = { 5, 5, 30, 5 };  // 上，左，下，右
    //左上角查找范围 {{minX,maxX,safeX},{minY,maxY,safeY}}
    _ValRange leftTopRange[2] = { _ValRange { 0, 20, 20 }, _ValRange { -5, 20, 25 } };
    //右下角查找范围 {{maxX,minX,safeX},{maxY,minY,safeY}}
    _ValRange rightBottomRange[2] = { _ValRange { width + 15, width - 20, width - 20 }, _ValRange { height - 22, height - 55, height - 15 } };

    //电机准备
    motors_unstep();
    motors_set_disable(false);

    //初始X轴
    motorX.setAcceleration(toStepX(5000));
    motorX.setSpeed(0);
    motorX.setMaxSpeed(toStepX(5000 / 60));

    //初始Y轴
    motorY.setAcceleration(toStepY(5000));
    motorY.setSpeed(0);
    motorY.setMaxSpeed(toStepY(5000 / 60));

    // 回到原位
    motorX.runToNewPosition(toStepX(0));
    motorY.runToNewPosition(toStepY(0));

    float currXPos = toMMX(motorX.currentPosition());
    float currYPos = toMMY(motorY.currentPosition());

    bool seekstatus = false;
    //开启寻边传感器
    pinMode(PIN_SEEK_BOX, INPUT);

    //找左上点
    _PointInfo2 leftTopPoint = SJMotorCtrl::SeekMarkPoint(vClient, leftTopRange);

    // 回到原位
    motorX.runToNewPosition(toStepX(currXPos));
    motorY.runToNewPosition(toStepY(currYPos));

    // 判断是否找到左上点
    if (leftTopPoint.status) {
        // grbl_sendf(vClient, "leftTopPoint %0.2f,%0.2f\r\n", leftTopPoint.x, leftTopPoint.y);
        // 找右下点
        _PointInfo2 rightBottomPoint = SJMotorCtrl::SeekMarkPoint(vClient, rightBottomRange);
        // grbl_sendf(vClient, "rightBottomPoint %0.2f,%0.2f\r\n", rightBottomPoint.x, rightBottomPoint.y);
        // 判断是否找到右下点
        if (rightBottomPoint.status) {
            // 计算页边间距
            float xaxis_margin = (marks_margin[1] + marks_margin[3]);
            float yaxis_margin = (marks_margin[0] + marks_margin[2]);

            // float realwidth  = 200;
            float realwidth = width - xaxis_margin;
            // float realheight = 262;
            float realheight = height - yaxis_margin;

            // 计算无偏移情况下右下应该出现的位置
            _PointInfo vrbPoint = { x: leftTopPoint.x + realwidth, y: leftTopPoint.y + realheight };  // 虚拟左下点

            grbl_sendf(vClient,
                       "SEEK: %d,%0.5f,%0.5f,%0.5f\r\n",
                       taskIndex,
                       (leftTopPoint.x - marks_margin[1]- 12),
                       (leftTopPoint.y - marks_margin[0]- 10),
                       SJMotorCtrl::cacleAngle(vrbPoint, rightBottomPoint, leftTopPoint));
            seekstatus = true;
        }
    }

    // 回到原位
    motorX.runToNewPosition(toStepX(currXPos));
    motorY.runToNewPosition(toStepY(currYPos));

    //归位
    // motorX.runToNewPosition(0);
    // motorY.runToNewPosition(0);

    //释放电机
    motors_unstep();
    motors_set_disable(true);

    return seekstatus;
}
