#include "../PointQueue.h"

 

 
PointQueue::PointQueue(int size){            
    maxSize=size;
    _tag1_count=0;
    _tag2_count=0;
}
PointQueue::PointQueue(){            
    maxSize=85;
    _tag1_count=0;
    _tag2_count=0;
    _tag3_count=0;
}

void PointQueue::push(_PointInfo point,int tag){
    if(tag==1){
        // 先填充先导标记队列,出现纸
        _tag1_count++;
        _tag3_count=0;
        if(_tag1_count>50){
            this->clear();
        }
    }else if(tag==3){
        _tag3_count++;
        //_tag2_count=0;
        // 保留有用标记，出现标记
        if( _queue.size()<this->maxSize){
            _queue.push(point);
        }else{
            _queue.pop();
            _queue.push(point);
        }
    }else{
        _tag2_count++;
        _tag3_count=0;
        if(_tag2_count>50){
            _tag2_count=0;
            this->clear();
        }

    }
}

_PointInfo PointQueue::front(){
    return _queue.front();
}

bool PointQueue::isFulled(){ 
    if(_tag3_count > 80)
    return (_queue.size()==this->maxSize);
    else
    return (_tag1_count>5&&_queue.size()==this->maxSize);
}

bool PointQueue::empty(){
    return _queue.empty();
}

void PointQueue::clear(){
    while (_queue.size()>0)
    {
        _queue.pop();
    }            
}

int PointQueue::rsize(){
    return _queue.size();  
}

int PointQueue::tsize(){
    return _tag1_count;
}