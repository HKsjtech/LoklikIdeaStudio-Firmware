#pragma once
#ifndef POINTQUEUE_H
#define POINTQUEUE_H

 
#include <queue> 
 

struct _PointInfo {		
	float x;
	float y;
    bool status;
};

struct _PointInfo2 {		
	float x;
	float y;
    float x2;
	float y2;
    bool status;
};

class PointQueue{
    private:
        int maxSize;
        // _PointInfo *array;        
        std::queue<_PointInfo> _queue;
        int _tag1_count;
        int _tag2_count;
        int _tag3_count;
    public:
        PointQueue();
        PointQueue(int size);

        void push(_PointInfo point,int tag);

        _PointInfo front();

        bool isFulled();

        bool empty();

        void clear();

        int rsize();
        int tsize();

};


#endif