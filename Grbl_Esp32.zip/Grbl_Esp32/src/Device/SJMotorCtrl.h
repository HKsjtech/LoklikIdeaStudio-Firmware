// Copyright (c) 2022 -	Neil
#ifndef __SJMOTORCTRL_HPP__
#define __SJMOTORCTRL_HPP__



struct _ValRange {		
	float min;
	float max;
    float safe;
};


class SJMotorCtrl {
public:
    static void init();
    static void loop();   
    static bool zAxisHoming(uint8_t client);
    static bool yAxisHoming(uint8_t client);
    static bool xyAxisHoming(uint8_t client, bool vMiddle);
    static void enableMotor(void);
    static void disableMotor(void);
    static void runTest(uint8_t client);
    static bool loadMate(uint8_t client);
    static bool unLoadMate(uint8_t client);
    static bool resetAxis(uint8_t client);
    static bool absMoveAxis(uint8_t client, uint axis, float moveDist);
    static bool relMoveAxis(uint8_t client, uint axis, float moveDist);


    static _PointInfo  cacleExtendLength(_PointInfo pointA,_PointInfo pointB,float length );
    static _PointInfo cacleIntersect(_PointInfo p1, _PointInfo p2, _PointInfo p3, _PointInfo p4);
    static float cacleAngle(_PointInfo p1, _PointInfo2 p2, _PointInfo2 p3);
    static bool SeekMark(int vClient, int taskIndex, float width, float height); 
    static bool SeekMark2(int vClient, int taskIndex, float width, float height); 
    static _PointInfo2 SeekMarkPoint(int vClient, _ValRange target_range[2]);
    static _PointInfo TestSeekPointByArea(int vClient, _PointInfo sensorOffset,int axis,float safev, float val1, float val2,float step);
    static int TestSeekPointByXY(int vClient, _PointInfo sensorOffset, float x, float y);
};

#endif